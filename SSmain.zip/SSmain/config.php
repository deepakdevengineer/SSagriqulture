<?php

// Razorpay API credentials
define('RAZORPAY_KEY_ID', 'rzp_test_7AAvczxYAMW3nY');
define('RAZORPAY_KEY_SECRET', 'wPeEfwG3dit3sO0TyNbUit2U');

// Display currency
define('DISPLAY_CURRENCY', 'INR');

// Autoload Composer dependencies
require_once 'vendor/autoload.php';  // Adjust the path based on your project structure

// Other configuration settings can be added here
// For example, database connection details, etc.

?>
