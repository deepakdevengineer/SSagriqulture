 <footer class="footer" style="text-align: center;">SS AGRIQULTURE © 2023 - SS AGRIQULTURE TECH TEAM- </footer>
