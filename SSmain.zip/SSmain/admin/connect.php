<?php
$servername = 'localhost';
$port = 3308; // Your custom MySQL port
$username = 'root';
$password = ''; // Replace with the actual password
$database = 'sswebsite';

// Create connection with port specified
$conn = mysqli_connect($servername, $username, $password, $database,$port); // connecting 
// Check connection
if (!$conn) {       //checking connection to DB	
    die("Connection failed: " . mysqli_connect_error());
}

?>