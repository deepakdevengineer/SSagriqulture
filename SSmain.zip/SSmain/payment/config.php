<?php

$keyId = 'rzp_test_7AAvczxYAMW3nY'; // Replace with your Razorpay key
$keySecret = 'PeEfwG3dit3sO0TyNbUit2U';

?>
